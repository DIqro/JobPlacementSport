<?php $__env->startSection("content-admin"); ?>

  <div class="container">
    <h2>Daftar Lowongan Pekerjaan yang Valid</h2>
    <table class="table table-striped">
      <thead>
        <tr>
          <th>ID</th>
          <th>Judul Lowker</th>
          <th>Pemilik</th>
          <th>Deadline Lowker</th>
          <th>Kategori</th>
          <th class="text-center">Aksi</th>
        </tr>
      </thead>

      <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($dt->id); ?></td>
            <td><?php echo e($dt->judul); ?></td>
            <td><?php echo e($dt->nama); ?></td>
            <td><?php echo e($dt->deadline); ?></td>
            <td><?php echo e($dt->kategori); ?></td>
            <td class="text-center">
              <button id='setuju-lowker' data-toggle="modal" data-target="#modalEdit<?php echo e($dt->id); ?>" class="btn-xs btn-success"><i class="fa fa-pencil"></i> Edit</button>
              <button id='tolak-lowker' data-toggle="modal" data-target="#modalDelete<?php echo e($dt->id); ?>" class="btn-xs btn-danger" type="submit"><i class="fa fa-trash-o"></i> Hapus</button>
            </td>
          </tr>
          <?php echo $__env->make('layouts.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
<script>
function klikValidasi(){
  $("button").click(function() {
    if(this.id == 'setuju-lowker'){
      $('#message').text('Anda yakin ingin MENYETUJUI lowker ini?');
      $('#aksi').val('setuju');
    }else if(this.id == 'tolak-lowker'){
      $('#message').text('Anda yakin TIDAK MENYETUJUI Lowker ini?');
      $('#aksi').val('tidak-setuju');
    }
  });
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.menu-admin", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>