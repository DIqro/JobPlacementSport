<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12 col-md-offset-0">
            <div class="panel panel-default">
                <center><div class="panel-heading"><h3>Daftar Lowongan Pekerjaan</h3></div></center>
            </div>
        </div>

        <?php $__currentLoopData = $lowker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    	<?php echo $__env->make('layouts.lowker', array('data' => $dt), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>