<?php $__env->startSection('title', 'JPS | Tambah lowker'); ?>
<?php $__env->startSection('content'); ?>
<div class="banner">
    <div class="container">
        <div id="search_wrapper">
            <div id="search_form" class="clearfix">
                <h1>Start your job search</h1>
                <p>
                     <input type="text" class="text" placeholder=" " value="Enter Keyword(s)" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Enter Keyword(s)';}">
                     <input type="text" class="text" placeholder=" " value="Location" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Location';}">
                     <label class="btn2 btn-2 btn2-1b"><input type="submit" value="Find Jobs"></label>
                </p> 
            </div> 
        </div>
    </div> 
</div>  
<div class="container">
    <div class="single">  
       <div class="form-container">
        <h2>Create aJob</h2>
        <form>
          <div class="row">
            <div class="form-group col-md-12">
                <label class="col-md-3 control-lable" for="title">Title</label>
                <div class="col-md-9">
                    <input type="text" path="title" id="title" class="form-control input-sm"/>
                </div>
            </div>
         </div>
         <div class="row">
            <div class="form-group col-md-12">
                <label class="col-md-3 control-lable" for="insName">Institution Name</label>
                <div class="col-md-9">
                    <input type="text" path="insName" id="insName" class="form-control input-sm"/>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-12">
                <label class="col-md-3 control-lable" for="address">Address</label>
                <div class="col-md-9">
                    <input type="text" path="address" id="address" class="form-control input-sm"/>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-12">
                <label class="col-md-3 control-lable" for="validPeri">Validity Period</label>
                <div class="col-md-9">
                    <input type="text" path="validPeri" id="validPeri" class="form-control input-sm"/>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-12">
                <label class="col-md-3 control-lable" for="salary">Salary/ Month</label>
                <div class="col-md-9">
                    <input type="text" path="salary" id="salary" class="form-control input-sm"/>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-12">
                <label class="col-md-3 control-lable" for="deadline">Deadline for Apply</label>
                <div class="col-md-9">
                    <input type="date" path="deadline" id="deadline" class="form-control input-sm"/>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-12">
                <label class="col-md-3 control-lable" for="insAdd">Institution Address</label>
                <div class="col-md-9">
                    <input type="text" path="insAdd" id="insAdd" class="form-control input-sm"/>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-12">
                <label class="col-md-3 control-lable" for="insCon">Institution Contact</label>
                <div class="col-md-9">
                    <input type="text" path="insCon" id="insCon" class="form-control input-sm"/>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-12">
                <label class="col-md-3 control-lable" for="jobCat">Job Category</label>
                <div class="col-md-9">
                    <select path="jobCat" id="jobCat" class="form-control input-sm">
                        <option value="">General</option>
                        <option value="">Specific</option>
                    </select>
               </div>
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-12">
                <label class="col-md-3 control-lable" for="description">Description</label>
                <div class="col-md-9 sm_1">
                   <textarea cols="77" rows="6" value=" " onfocus="this.value='';" onblur="if (this.value == '') {this.value = '';}"> </textarea>
                    
                </div>
            </div>
        </div>
        <div class="row">
            <div class="form-actions floatRight">
                <input type="submit" value="Create Job" class="btn btn-primary btn-sm">
            </div>
        </div>
    </form>
    </div>
 </div>
</div>
<div class="footer">
    <div class="container">
        <div class="col-md-4 grid_3">
            <h4>Navigate</h4>
            <ul class="f_list f_list1">
                <li><a href="home.html">Home</a></li>
                <li><a href="index.html">Sign In</a></li>
                <li><a href="signup.html">Join Now</a></li>
                <li><a href="about.html">About</a></li>
            </ul>
            <ul class="f_list">
                <li><a href="features.html">Features</a></li>
                <li><a href="terms.html">Terms of use</a></li>
                <li><a href="contact.html">Contact Us</a></li>
                <li><a href="jobs.html">Post a Job</a></li>
            </ul>
            <div class="clearfix"> </div>
        </div>
        <div class="col-md-4 grid_3">
            <h4>Job Placement Sport</h4>
            <p>Job Placement Sport is a useful web-based application to help users find job vacancies and seek employment in sports. Users looking for job vacancies can directly apply for the desired job vacancy through Job Placement Sport application and for users looking for a workforce can directly select applicants through Job Placement Sport application. </p>
        </div>
        <div class="col-md-4 grid_3">
            <h4>Sign up for our newsletter</h4>
            <form>
                <input type="text" class="form-control" placeholder="Enter your email">
                <button type="button" class="btn red">Subscribe now!</button>
            </form>
        </div>
        <div class="clearfix"> </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>