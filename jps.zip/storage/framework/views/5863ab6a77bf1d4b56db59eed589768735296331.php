<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            
            <?php if(session('notif')): ?>
                <div class="alert alert-danger alert-dismissable">
                    <a href="#" aria-label="close" class="close" data-dismiss="alert">&times;</a>
                    <strong><?php echo e(session('notif')); ?></strong> 
                </div>
            <?php endif; ?>
            <?php if(session('terdaftar')): ?>
                <div class="alert alert-success alert-dismissable">
                    <a href="#" aria-label="close" class="close" data-dismiss="alert">&times;</a>
                    <strong><?php echo e(session('terdaftar')); ?></strong> 
                </div>
            <?php endif; ?>
            
            <div class="panel panel-default">
                <div class="panel-heading"><h3>Tambah Lowongan Pekerjaan baru</h3></div>

                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="<?php echo e(url('lowker/simpan-lowker')); ?>">
                        <div class="form-group<?php echo e($errors->has('judul') ? ' has-error' : ''); ?>">
                            <label for="judul" class="col-md-4 control-label">Judul</label>

                            <div class="col-md-6">
                                <input id="judul" type="text" class="form-control" name="judul" value="<?php echo e(old('judul')); ?>" >

                                <?php if($errors->has('judul')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('judul')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('nama_lembaga') ? ' has-error' : ''); ?>">
                            <label for="nama_lembaga" class="col-md-4 control-label">Nama Lembaga</label>

                            <div class="col-md-6">
                                <input id="nama_lembaga" type="text" class="form-control" name="nama_lembaga" value="<?php echo e(old('nama_lembaga')); ?>" >

                                <?php if($errors->has('nama_lembaga')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('nama_lembaga')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('syarat') ? ' has-error' : ''); ?>">
                            <label for="syarat" class="col-md-4 control-label">Syarat dan Ketentuan</label>

                            <div class="col-md-6">
                                <input id="syarat" type="text" class="form-control" name="syarat" value="<?php echo e(old('syarat')); ?>" >

                                <?php if($errors->has('syarat')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('syarat')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('masa_berlaku') ? ' has-error' : ''); ?>">
                            <label for="masa_berlaku" class="col-md-4 control-label">Masa Berlaku</label>

                            <div class="col-md-6">
                                <input id="masa_berlaku" type="text" class="form-control" name="masa_berlaku" value="<?php echo e(old('masa_berlaku')); ?>" >

                                <?php if($errors->has('masa_berlaku')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('masa_berlaku')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('gaji') ? ' has-error' : ''); ?>">
                            <label for="gaji" class="col-md-4 control-label">Gaji/bulan</label>

                            <div class="col-md-6">
                                <input id="gaji" type="text" class="form-control" name="gaji" value="<?php echo e(old('gaji')); ?>" >

                                <?php if($errors->has('gaji')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('gaji')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('deadline') ? ' has-error' : ''); ?>">
                            <label for="deadline" class="col-md-4 control-label">Deadline pengumpulan berkas</label>

                            <div class="col-md-6">
                                <input id="deadline" type="text" class="form-control" name="deadline" value="<?php echo e(old('deadline')); ?>" placeholder="ex : 2017-11-07">

                                <?php if($errors->has('deadline')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('deadline')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('alamat') ? ' has-error' : ''); ?>">
                            <label for="alamat" class="col-md-4 control-label">Alamat Lembaga</label>

                            <div class="col-md-6">
                                <input id="alamat" type="text" class="form-control" name="alamat" value="<?php echo e(old('alamat')); ?>" >

                                <?php if($errors->has('alamat')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('alamat')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('kontak') ? ' has-error' : ''); ?>">
                            <label for="kontak" class="col-md-4 control-label">Kontak Lembaga</label>

                            <div class="col-md-6">
                                <input id="kontak" type="text" class="form-control" name="kontak" value="<?php echo e(old('kontak')); ?>" >

                                <?php if($errors->has('kontak')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('kontak')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('kategori') ? ' has-error' : ''); ?>">
                            <label for="kategori" class="col-md-4 control-label">Kategori Pekerjaan</label>

                            <div class="col-md-6">
                                <input id="kategori" type="text" class="form-control" name="kategori" value="<?php echo e(old('kategori')); ?>" >

                                <?php if($errors->has('kategori')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('kategori')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('deskripsi') ? ' has-error' : ''); ?>">
                            <label for="deskripsi" class="col-md-4 control-label">Deskripsi</label>

                            <div class="col-md-6">
                                <textarea id="deskripsi" type="text" class="form-control" name="deskripsi"><?php echo e(old('deskripsi')); ?></textarea>

                                <?php if($errors->has('deskripsi')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('deskripsi')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary" name="btn_tambah">
                                    Tambah Lowongan
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>