<?php $__env->startSection('title', 'JPS | Tambah lowker'); ?>
<?php $__env->startSection('content'); ?>
<div class="banner_1">
</div>	

<div class="container">
	<div class="col-md-8 col-md-offset-2 notifikasi">
		<h2>Notification</h2>
        <?php if(count($notifikasi) > 0): ?>
            <ul class="list-group">
            <?php $__currentLoopData = $notifikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php 
                if($info->pesan == "lolos"){
                    $colors = "#dff0d8";
                    $isi = " Selamat, anda lolos seleksi ke tahap selanjutnya";
                }else{
                    $colors = "#f2dede";
                    $isi = " Maaf, anda tidak lolos pada seleksi pekerjaan ini. Tetap semangat";
                }
               ?>
            <a href='<?php echo e(url("lowker/$info->id_lowker")); ?>'>
                <li class="list-group-item" style="background-color: <?php echo e($colors); ?>">
                    <p>Dari : <strong> <?php echo e($info->nama_lembaga); ?> </strong><br>
                        <?php echo e($isi); ?>

                    </p>
                    <p><?php echo e($info->waktu); ?></p>
                </li>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <div class="alert alert-warning" align="center">
                <strong>Tidak</strong> terdapat notifikasi!.
            </div> 
        <?php endif; ?>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>