<?php $__env->startSection('title', 'JPS | Halaman utama'); ?>
<?php $__env->startSection('content'); ?>
<div class="banner">
</div>	
<div class="container"> 
	<div class="single">
		<?php $__currentLoopData = $lowker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <div class="col-md-4">
			<div class="col_3"> 
	   	  		<div class="col-sm-8 row_1">
					<h4>
						<a href='<?php echo e(url("lowker/$dt->id_lowker")); ?>'>
							<?php if(strlen($dt->judul) > 17): ?>
				            	<?php echo e(substr($dt->deskripsi, 0, 17)); ?>. .
				            <?php else: ?>
								<?php echo e($dt->judul); ?>

				            <?php endif; ?>
						</a>
					</h4>
					<h6><?php echo e($dt->tgl_post); ?></h6>
					<?php if(strlen($dt->deskripsi) > 60): ?>
		            	<p style="height: 30px"><?php echo e(substr($dt->deskripsi, 0, 60)); ?>. . .</p>
		            <?php else: ?>
		            	<p style="height: 30px"><?php echo e($dt->deskripsi); ?></p>
		            <?php endif; ?>
				</div>
			</div>
		</div>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>