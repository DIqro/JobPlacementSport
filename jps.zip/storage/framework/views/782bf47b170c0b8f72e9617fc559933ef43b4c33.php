<?php //for($i = 0; $i < 7; $i++){?>
<a href='<?php echo e(url("lowker/$data->id")); ?>'>
<div class="col-md-3 col-md-offset-0">
    <div class="panel panel-default">
        <div class="panel-heading"><?php echo e($data->judul); ?></div>
        <div class="panel-body">
            <?php echo e($data->deskripsi); ?>

        </div>
    </div>
</div>
</a>