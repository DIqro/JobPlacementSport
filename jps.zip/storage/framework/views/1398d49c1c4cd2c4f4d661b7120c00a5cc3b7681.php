<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row content">
        <h4><strong>Notifikasi</strong></h4>
        <?php if(count($notifikasi) > 0): ?>
            <?php $__currentLoopData = $notifikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php 
                if($info->pesan == "lolos"){
                    $colors = "#dff0d8";
                    $isi = " Selamat, anda lolos seleksi ke tahap selanjutnya";
                }else{
                    $colors = "#f2dede";
                    $isi = " Maaf, anda tidak lolos pada seleksi pekerjaan ini. Tetap semangat";
                }
               ?>    
                <div class="col-sm-12" style="background-color: <?php echo e($colors); ?>">
                    <a href='<?php echo e(url("lowker/$info->id_lowker")); ?>'>
                        <div class="col-sm-12">
                            <p>Dari : <strong> <?php echo e($info->nama_lembaga); ?> </strong><br>
                                <?php echo e($isi); ?>

                            </p>
                            <p><?php echo e($info->waktu); ?></p>
                        </div> 
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="alert alert-warning" align="center">
                <strong>Tidak</strong> terdapat notifikasi!.
            </div> 
        <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>