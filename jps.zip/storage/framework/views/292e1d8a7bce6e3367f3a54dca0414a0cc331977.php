<?php $__env->startSection('title', 'JPS | Tambah lowker'); ?>
<?php $__env->startSection('content'); ?>
<div class="banner_1">
</div> 
<div class="container">
    <div class="single">  
       <div class="form-container">
        <h2>Create Job</h2>
        <form action="<?php echo e(url('lowker/tambah-lowker')); ?>" method="post">
            <?php 
                $info = array('Title', 'Institution Name', 'Job Category', 'Requirements', 'Validity Period', 'Salary/ Month', 'Deadline for Apply', 'Address', 'Contact');
                $name = array('judul', 'nama_lembaga', 'kategori', 'syarat', 'masa_berlaku', 'gaji', 'deadline', 'alamat', 'kontak');
             ?>

            <?php for($i = 0; $i < count($info); $i++): ?>
                <div class="row">
                    <div class='form-group col-md-12 <?php echo e($errors->has("$name[$i]") ? " has-error" : ""); ?>'>
                        <label class="col-md-3 control-lable" for="judul"><?php echo e($info[$i]); ?></label>

                        <div class="col-md-9">
                            <input id="<?php echo e($name[$i]); ?>" type="text" class="form-control" name="<?php echo e($name[$i]); ?>" value='<?php echo e(old("$name[$i]")); ?>' placeholder="<?php echo e($name[$i] == 'deadline' ? 'ex : 2017-12-08' : ''); ?> ">
                            <?php if($errors->has("$name[$i]")): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first($name[$i])); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endfor; ?>
            <div class="row">
                <div class='form-group col-md-12 <?php echo e($errors->has("deskripsi") ? " has-error" : ""); ?>'>
                    <label class="col-md-3 control-lable" for="description">Description</label>
                    <div class="col-md-9 sm_1">
                        <textarea cols="77" rows="6" onfocus="this.value='';" onblur="if (this.value == '') {this.value = '';}" name="deskripsi" class="form-control"><?php echo e(old("deskripsi")); ?></textarea>
                        <?php if($errors->has("deskripsi")): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('deskripsi')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="form-actions floatRight">
                    <input type="submit" value="Tambah Lowongan" class="btn btn-primary btn-sm">
                </div>
            </div>
        </form>
    </div>
 </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>