<?php $__env->startSection("content-admin"); ?>

  <div class="container">
    <h2>Tabel Validasi Lowongan Pekerjaan</h2>                
    <table class="table table-striped">
      <thead>
        <tr>
          <th>Judul Lowker</th>
          <th>Pemilik</th>
          <th>Deadline Lowker</th>
          <th>Kategori</th>
          <th>Aksi</th>
        </tr>
      </thead>

      <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($dt->judul); ?></td>
            <td><?php echo e($dt->nama); ?></td>
            <td><?php echo e($dt->deadline); ?></td>
            <td><?php echo e($dt->kategori); ?></td>
            <td><span class="glyphicon glyphicon-ok"></span> Setuju | <span class="glyphicon glyphicon-remove"></span> Tidak Setuju</td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <tr>
          <td>Dicari atlet . ..</td>
          <td>wahyu</td>
          <td>06-11-2017</td>
          <td>Pelatih</td>
          <td><span class="glyphicon glyphicon-ok"></span> Setuju | <span class="glyphicon glyphicon-remove"></span> Tidak Setuju</td>
        </tr>

        <tr>
          <td>Dibutuhkan pelatih</td>
          <td>dika</td>
          <td>31-12-2017</td>
          <td>Pelatih</td>
          <td><span class="glyphicon glyphicon-ok"></span> Setuju | <span class="glyphicon glyphicon-remove"></span> Tidak Setuju</td>
        </tr>

        <tr>
          <td>Dibutuhkan komentator</td>
          <td>doni</td>
          <td>21-09-2017</td>
          <td>Veteran</td>
          <td><span class="glyphicon glyphicon-ok"></span> Setuju | <span class="glyphicon glyphicon-remove"></span> Tidak Setuju</td>
        </tr>

        <tr>
          <td>Dibutuhkan pelatih</td>
          <td>Agus</td>
          <td>10-10-2017</td>
          <td>Atlet</td>
          <td><span class="glyphicon glyphicon-ok"></span> Setuju | <span class="glyphicon glyphicon-remove"></span> Tidak Setuju</td>
        </tr>

        <tr>
          <td>Dicari atlet . ..</td>
          <td>wahyu</td>
          <td>06-11-2017</td>
          <td>Pelatih</td>
          <td><span class="glyphicon glyphicon-ok"></span> Setuju | <span class="glyphicon glyphicon-remove"></span> Tidak Setuju</td>
        </tr>

        <tr>
          <td>Dibutuhkan pelatih</td>
          <td>dika</td>
          <td>31-12-2017</td>
          <td>Pelatih</td>
          <td><span class="glyphicon glyphicon-ok"></span> Setuju | <span class="glyphicon glyphicon-remove"></span> Tidak Setuju</td>
        </tr>

        <tr>
          <td>Dibutuhkan komentator</td>
          <td>doni</td>
          <td>21-09-2017</td>
          <td>Veteran</td>
          <td><span class="glyphicon glyphicon-ok"></span> Setuju | <span class="glyphicon glyphicon-remove"></span> Tidak Setuju</td>
        </tr>        
      </tbody>

    </table>
  </div>

  <div class="table-responsive" >
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.menu-admin", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>