<?php $__env->startSection("content-admin"); ?>

  <div class="container">
    <h2>Tabel Data Pelamar</h2>
    <table class="table table-striped">
      <thead>
        <tr>
          <th>ID</th>
          <th>Nama</th>
          <th>Email</th>
          <th>Alamat</th>
          <th>Tanggal Lahir</th>
          <th class="text-center">Aksi</th>
        </tr>
      </thead>

      <tbody>
        <?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($dt->id); ?></td>
          <td><?php echo e($dt->nama); ?></td>
          <td><?php echo e($dt->email); ?></td>
          <td><?php echo e($dt->alamat); ?></td>
          <td><?php echo e($dt->tgl_lahir); ?></td>
          <td class="text-center">
              <button id='setuju-lowker' data-toggle="modal" data-target="#modalEditAkun<?php echo e($dt->id); ?>" class="btn-xs btn-success"><i class="fa fa-pencil"></i> Edit</button>
              <button id='tolak-lowker' data-toggle="modal" data-target="#modalDeleteAkun<?php echo e($dt->id); ?>" class="btn-xs btn-danger" type="submit"><i class="fa fa-trash-o"></i> Hapus</button>
            </td>
        </tr>
        <?php echo $__env->make("layouts.modal", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.menu-admin", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>