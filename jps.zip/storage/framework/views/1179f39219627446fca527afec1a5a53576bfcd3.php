<?php //for($i = 0; $i < 3; $i++){?>
<a href='<?php echo e(url("lowker/$data->id")); ?>'>
	<div class="col-md-3 col-md-offset-0">
	    <div class="panel panel-default">
	        <div class="panel-heading"><?php echo e($data->judul); ?></div>
	        <div class="panel-body">
	        	<?php if(strlen($data->deskripsi) > 120): ?>
	            	<?php echo e(substr($data->deskripsi, 0, 120)); ?>. . .
	            <?php else: ?>
	            	<?php echo e($data->deskripsi); ?>

	            <?php endif; ?>
	        </div>
	    </div>
	</div>
</a>
<?php//	 }?>