<?php $__env->startSection("content"); ?>
<style>
    div.container {
        width: 90%;
    }
</style>
<div class="container-fluid">
  <div class="row content">
      <div class="col-sm-2 sidenav">
        <h4> <a href="<?php echo e(URL('')); ?>"><span class="glyphicon glyphicon-user"></span> <?php echo e(Session::get('nama')); ?></a></h4>
        <div id="menu">
          <ul class="nav nav-pills nav-stacked">
            <li><a href="<?php echo e(URL('/validasi-lowker')); ?>"><span class="glyphicon glyphicon-ok"></span> Validasi LowKer</a></li>
            <li><a href="<?php echo e(URL('/data-lowker-valid')); ?>"><i class="fa fa-copyright"></i> Data LowKer Valid</a></li>
            <li><a href="<?php echo e(URL('/data-pengguna')); ?>"><span class="glyphicon glyphicon-list-alt"></span> Data Pengguna</a></li>
            <li><a href="<?php echo e(URL('/data-pelamar')); ?>"><span class="glyphicon glyphicon-list-alt"></span> Data Pelamar</a></li>
            <li><a href="<?php echo e(URL('/lowker-ditolak')); ?>"><span class="glyphicon glyphicon-trash"></span> LowKer Tertolak</a></li>
          </ul>
        </div>
      </div>
    <div class="col-sm-10" id="right-side" style="background-color: white">
      <?php if(session('notif')): ?>
        <?php if(session('key') == 'sukses'): ?>
            <div class="alert alert-success alert-dismissable" align='center'>
        <?php else: ?>
            <div class="alert alert-danger alert-dismissable" align='center'>
        <?php endif; ?>
                <a href="#" aria-label="close" class="close" data-dismiss="alert">&times;</a>
                <strong><?php echo e(session('notif')); ?></strong> 
            </div>
      <?php endif; ?>

      <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger alert-dismissable" align='center'>
            <a href="#" aria-label="close" class="close" data-dismiss="alert">&times;</a>
            <strong>Perubahan gagal, terdapat kesalahan. Klik ulang tombol Edit untuk mengetahuinya</strong> 
        </div>
      <?php endif; ?>
      <?php echo $__env->yieldContent("content-admin"); ?>
    </div>

  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>