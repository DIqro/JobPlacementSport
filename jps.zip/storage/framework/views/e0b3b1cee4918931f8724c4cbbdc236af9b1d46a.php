<?php $__env->startSection('title', 'JPS | Lowker'); ?>
<?php $__env->startSection('content'); ?>
<div class="banner_1">
</div><br>
<?php if(session('notif')): ?>
    <?php if(session('key') == 'sukses'): ?>
        <div class="alert alert-success alert-dismissable" align='center'>
    <?php else: ?>
        <div class="alert alert-danger alert-dismissable" align='center'>
    <?php endif; ?>
            <a href="#" aria-label="close" class="close" data-dismiss="alert">&times;</a>
            <strong><?php echo e(session('notif')); ?></strong> 
        </div>
<?php endif; ?>
<div class="container">
    <div class="single">  
	   
	 <div class="col-md-8 single_right"">
	      <h3><?php echo e($data->judul); ?></h3>
	      <h6><?php echo e($data->tgl_post); ?> - <?php echo e($data->nama); ?></h6>
	      <div class="row_1"  style="margin-top: 25px;">
	      	<div class="col-md-11">
	      		<p><strong>Requirement</strong></p>
	      		<p><?php echo e($data->syarat); ?></p>
	      	</div>
	      </div>
	      <div class="clearfix"> </div>
	      <div class="col-md-11">	
	      <p><strong>Description</strong></p>
	      <p><?php echo e($data->deskripsi); ?></p>
	  	</div>

	  	<div class="clearfix"> </div>
			
	      	<?php if(Auth::user()->id != $data->id_pemilik): ?>
                <?php if($total_melamar > 0): ?>
                    <div class="col-sm-12" align="center">
                        <p class="alert alert-warning"><strong>Anda sudah melamar pekerjaan ini</strong></p>
                    </div>
                <?php else: ?>
                    <form class="form-horizontal" method="POST" action="<?php echo e(url('lowker/lamar')); ?>">
				      	<center><input type="submit" name="melamar" value="Lamar Pekerjaan" class="btn btn-primary"></center>
                        <input type="hidden" name="id_lowker" value="<?php echo e($data->id_lowker); ?>">
                    </form>
                <?php endif; ?>
            <?php else: ?>
                <form class="form-horizontal" method="POST" action='<?php echo e(url("lowker/$data->id_lowker/pelamar")); ?>'>
			      	<center><input type="submit" name="melamar" value="Lihat Pelamar" class="btn btn-success""></center> 
                </form>
            <?php endif; ?>

	      <div class="comments">
	      	<h6>Comments</h6>
			<?php $__currentLoopData = $komentar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="media media_1">
			  <div class="media-left"> 
					<?php if(file_exists(public_path("members/$komen->id/$komen->id.jpg"))): ?>
                        <img class="img-circle" src='<?php echo e(asset("members/$komen->id/$komen->id.jpg")); ?>' style="width:70px; height:70px" title="<?php echo e($komen->tgl_komen); ?>">
                    <?php else: ?>
                        <img class="img-circle" src='<?php echo e(asset("members/default.jpg")); ?>' style="width:70px; height:70px" title="<?php echo e($komen->tgl_komen); ?>">
                    <?php endif; ?>
			  </div>
			  <div class="media-body">
			    <h4 class="media-heading"><?php echo e($komen->nama); ?> ~ <?php echo e($komen->tgl_komen); ?></a><div class="clearfix"> </div></h4>
			    <p title="<?php echo e($komen->tgl_komen); ?>"><?php echo e($komen->isi); ?></p>
			  </div>
			  <div class="clearfix"> </div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  </div>
		  <form action="<?php echo e(url('/lowker/komentari')); ?>" method="post">
			<div class="text">
				<div class="form-group<?php echo e($errors->has('komentar') ? ' has-error' : ''); ?>">
	               <textarea class="form-control" name="komentar" placeholder="Tulis komentar anda disini. . ." id="komentar"></textarea>
                    <p align="center" style="color: red"><strong><?php echo e($errors->first('komentar')); ?></strong></p>
	            </div>
            </div>
            <div class="form-submit1">
            	<input type="hidden" name="id_lowker" value="<?php echo e($data->id_lowker); ?>"><br>
	           <input name="submit" type="submit" id="submit" value="Komentari"><br>
	        </div>
			<div class="clearfix"></div>
          </form>
	   </div>
	   <!-- <div class="clearfix"> </div> -->
	 
	   <div class="col-md-4">
	   	  <div class="col_3">
	   	  	<h3>Detail Jobs</h3>
	   	  	<ul class="list_1">
	   	  		<li><strong>Title:</strong><br/><?php echo e($data->judul); ?></li>
	   	  		<li><strong>Institution Name:</strong><br/><?php echo e($data->nama_lembaga); ?></li>		
	   	  		<li><strong>Address:</strong><br/><?php echo e($data->alamat); ?></li>
	   	  		<li><strong>Validity Period:</strong><br/><?php echo e($data->masa_berlaku); ?></li>
	   	  		<li><strong>Salary/ Month:</strong><br/><?php echo e($data->gaji); ?></li>
	   	  		<li><strong>Deadline for Apply:</strong><br/><?php echo e($data->deadline); ?></li>
	   	  		<li><strong>Institution Contact:</strong><br/><?php echo e($data->kontak); ?></li>
	   	  		<li><strong>Job Category:</strong><br/><?php echo e($data->kategori); ?></li>
	   	  		<a href='<?php echo e(url("simpan-lowker/$data->id_lowker")); ?>' target="_blank"><li><i class="fa fa-download" aria-hidden="true"></i><strong>   Download This Job</strong></li></a>
	   	  	</ul>
	   	  </div>
	   	  <div class="col_3">
	   	  	<h3>Share</h3>
	   	  		<a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(Request::fullUrl())); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=no,scrollbars=no,height=400,width=600'); return false;"><i id="social" class="fa fa-facebook-square fa-3x"></i></a>
	   	  		<a href="https://twitter.com/intent/tweet?url=<?php echo e(urlencode(Request::fullUrl())); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=no,scrollbars=no,height=400,width=600'); return false;"><i id="social" class="fa fa-twitter-square fa-3x"></i></a>  	
	   	  </div>
	 </div>

	 </div>	 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>