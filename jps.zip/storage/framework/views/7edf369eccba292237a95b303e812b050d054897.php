<?php $__env->startSection('title', 'JPS | Profilku'); ?>
<?php $__env->startSection("content"); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $('a[data-toggle="tab"]').on('show.bs.tab', function(e) {
            localStorage.setItem('activeTab', $(e.target).attr('href'));
        });
        var activeTab = localStorage.getItem('activeTab');
        if(activeTab){
            $('#myTab a[href="' + activeTab + '"]').tab('show');
        }
    });
</script>
<br>
<div class="container-fluid">
    <div class="row content" >
        <div class="col-sm-2"></div>
        <div class="col-sm-8" style="background-color: #edf0f2; border-radius: 10px;">
              
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger alert-dismissable">
                <a href="#" aria-label="close" class="close" data-dismiss="alert">&times;</a>
                <strong>Perubahan data gagal. Terdapat kesalahan</strong> 
            </div>
        <?php endif; ?> 
        <?php if(session('notif')): ?>
            <?php if(session('key') == 'sukses'): ?>
               <div class="alert alert-success alert-dismissable">
            <?php else: ?>
                <div class="alert alert-danger alert-dismissable">
            <?php endif; ?>
                    <a href="#" aria-label="close" class="close" data-dismiss="alert">&times;</a>
                    <strong><?php echo e(session('notif')); ?></strong> 
                </div>
        <?php endif; ?>

            <ul class="nav nav-tabs" id='myTab'>
                <li class="active"><a data-toggle="tab" href="#profil">Profil</a></li>
                <li><a data-toggle="tab" href="#edit">Edit Profil</a></li>
                <li><a data-toggle="tab" href="#my_lowker">Lowker-ku</a></li>
                <li><a data-toggle="tab" href="#my_cv">CV-ku</a></li>
            </ul>

        <div class="well">
            <div class="tab-content" style="padding-top: 20px;">
                <div id="profil" class="tab-pane fade in active">
                    <div class="row content">
                        <div class="col-sm-4"></div>
                        <div class="col-sm-4">
                            <div class="row content">
                                <?php  $foto = asset("members/default.jpg");  ?>
                                <?php if(file_exists(public_path("members/$member->id/$member->id.jpg"))): ?>
                                    <?php  $foto = asset("members/$member->id/$member->id.jpg");  ?>
                                <?php endif; ?>
                                <?php  $hover = asset("members/change.jpg");  ?>
                                <label for="FileInput">
                                    <img src='<?php echo e($foto); ?>' style="cursor:pointer; width: 100%;" onmouseover="this.src='<?php echo e($hover); ?>'"onmouseout="this.src='<?php echo e($foto); ?>'" title="Klik untuk mengganti foto profil">
                                </label>
                                <form enctype="multipart/form-data" method="POST", action="<?php echo e(url('update-foto')); ?>" class="form-horizontal">
                                    <input type="file" id="FileInput" name="foto" style="cursor: pointer; display: none">
                                    <input type="submit" id="Up" style="display: none;">
                                </form>
                            </div>

                        </div>
                        <div class="col-sm-4"></div>
                    </div><br>

                    <?php if($errors->has('foto')): ?>
                        <strong><p style="color: red" align="center" id='notif_error'>Gagal mengubah foto. <?php echo e($errors->first('foto')); ?></p></strong>
                    <?php endif; ?>

                    <div class="row content" style="margin-top: 10px;">
                        <div class="col-sm-1"></div>
                        <div class="col-sm-10">
                            <div class="well" align="center">
                                <p><strong><?php echo e($member->nama); ?></strong></p>
                                <p><i class="fa fa-envelope-o" style="padding-right: 10px;"></i><?php echo e($member->email); ?></p>
                                <p><i class="fa fa-home" style="padding-right: 10px;"></i><?php echo e($member->alamat); ?></p>
                                <p><i class="fa fa-birthday-cake" style="padding-right: 10px;"></i><?php echo e($member->tgl_lahir); ?></p>
                            </div>
                        </div>
                    <div class="col-sm-1"></div>
                </div>
            </div>

        <div id="edit" class="tab-pane fade">
            <div class="row content">
                <form class="form-horizontal" method="POST" action="<?php echo e(url('update-profil')); ?>">

                    <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                        <label for="name" class="col-md-4 control-label">Nama</label>

                        <div class="col-md-6">
                            <input id="name" type="text" class="form-control" name="name" value="<?php echo e($member->nama); ?>" >

                            <?php if($errors->has('name')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <label for="email" class="col-md-4 control-label">E-Mail</label>

                        <div class="col-md-6">
                            <input id="email" type="email" class="form-control" name="email" value="<?php echo e($member->email); ?>" >

                            <?php if($errors->has('email')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('alamat') ? ' has-error' : ''); ?>">
                        <label for="alamat" class="col-md-4 control-label">Alamat</label>

                        <div class="col-md-6">
                            <input id="alamat" type="text" class="form-control" name="alamat" value="<?php echo e($member->alamat); ?>" >

                            <?php if($errors->has('alamat')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('alamat')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('tgl_lahir') ? ' has-error' : ''); ?>">
                        <label for="tgl_lahir" class="col-md-4 control-label">Tanggal Lahir</label>

                        <div class="col-md-6">
                            <input id="tgl_lahir" type="text" class="form-control" name="tgl_lahir" value="<?php echo e($member->tgl_lahir); ?>" placeholder="ex : 1998-11-02">

                            <?php if($errors->has('tgl_lahir')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('tgl_lahir')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-md-6 col-md-offset-4">
                            <button type="submit" class="btn btn-primary">
                                Ubah Profil
                            </button>
                        </div>
                    </div>
                </form>

                <form class="form-horizontal" method="POST" action="<?php echo e(url('update-pw')); ?>">
                    <div class="form-group<?php echo e($errors->has('current_password') ? ' has-error' : ''); ?>">
                        <label for="password" class="col-md-4 control-label">Password Saat Ini</label>

                        <div class="col-md-6">
                            <input id="current_password" type="password" class="form-control" name="current_password" >

                            <?php if($errors->has('current_password')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('current_password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                        <label for="password" class="col-md-4 control-label">New Password</label>

                        <div class="col-md-6">
                            <input id="password" type="password" class="form-control" name="new_password" >

                            <?php if($errors->has('password')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="password-confirm" class="col-md-4 control-label">Confirm New Password</label>

                        <div class="col-md-6">
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" >
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-md-6 col-md-offset-4">
                            <button type="submit" class="btn btn-primary">
                                Ubah Password
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div id="my_lowker" class="tab-pane fade">
            <div class="row content">
                <?php $__currentLoopData = $lowker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('layouts.lowker', array('data' => $dt), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div id="my_cv" class="tab-pane fade">
            <div class="row content">
                <form action="<?php echo e(url('update-cv')); ?>" method="POST" class="" class="form-horizontal" enctype="multipart/form-data">
                    <div class="form-inline">
                        <label for="file_cv" class="col-md-3 control-label">File CV</label>
                        <input id="file_cv" type="file" class="form-control" name="file_cv">
                        <button type="submit" class="btn btn-primary"> Simpan</button>
                    </div>
                </form>
                <div class="form-group has-error" align="center">
                    <div class="col-md-12">
                        <?php if($errors->has('file_cv')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('file_cv')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div><br><br>

                <table  class="table table-striped">
                    <thead style="background-color: #03a9f4">
                        <tr>
                          <th class="text-center">Dokumen</th>
                          <th class="text-center">#</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="text-center">CV</td>
                            <td class="text-center">
                            <?php if(file_exists(public_path("members/$member->id/$member->id.pdf"))): ?>
                                <a class="btn-sm btn-success" href="<?php echo e(url('profil/my-cv')); ?>" target="_blank"><i class="fa fa-eye"></i> Preview</a>
                            <?php else: ?>
                                <p style="color: red">Anda belum upload CV</p>
                            <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
      </div>
    </div>
  </div>
  </div>
</div>
<script type="text/javascript">
    $( "#FileInput" ).change(function() {
      $( "#Up" ).click();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>