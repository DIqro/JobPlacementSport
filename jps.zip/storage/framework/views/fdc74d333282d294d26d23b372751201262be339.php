<?php $__env->startSection("content"); ?>
<div class="container-fluid">
    <div class="row content">
        <?php if(session('notif')): ?>
            <?php if(session('key') == 'sukses'): ?>
                <div class="alert alert-success alert-dismissable" align='center'>
            <?php else: ?>
                <div class="alert alert-danger alert-dismissable" align='center'>
            <?php endif; ?>
                    <a href="#" aria-label="close" class="close" data-dismiss="alert">&times;</a>
                    <strong><?php echo e(session('notif')); ?></strong> 
                </div>
        <?php endif; ?>
        <div class="col-sm-6"  style="background-color: #edf0f2; border-radius: 10px;">
            <h4 align="center"><strong>Informasi Pekerjaan</strong></h4><br>
            <?php 
                $info = array('Judul', 'Nama Pemilik', 'Nama Lembaga', 'Kategori', 'Syarat', 'Masa Berlaku', 'Gaji', 'Deadline', 'Alamat', 'Kontak', 'Deskripsi', 'Dipost Sejak');
                $kolom = array('judul', 'nama', 'nama_lembaga', 'kategori', 'syarat', 'masa_berlaku', 'gaji', 'deadline', 'alamat', 'kontak', 'deskripsi', 'tgl_post');
             ?>

            <?php for($i = 0; $i < count($info); $i++): ?>
                <div class="col-sm-3">
                    <label><?php echo e($info[$i]); ?></label> 
                </div>
                <div class="col-sm-8">
                    <p><?php echo e($data->$kolom[$i]); ?></p>
                </div>
            <?php endfor; ?>

            <!-- member tidak dapat lamar lowkernya sendiri -->
            <?php if(Auth::user()->id != $data->id_pemilik): ?> 
                <form class="form-horizontal" method="POST" action="<?php echo e(url('lowker/lamar')); ?>">
                    <div class="form-group">
                        <div class="col-md-6 col-md-offset-4">
                            <input type="hidden" name="id_lowker"  value="<?php echo e($data->id); ?>">
                            <button type="submit" class="btn btn-primary">
                                Lamar Pekerjaan
                            </button>
                        </div>
                    </div>
                </form>
            <?php else: ?>

                <form class="form-horizontal" method="POST" action='<?php echo e(url("lowker/$data->id/pelamar")); ?>'>
                    <div class="form-group">
                        <div class="col-md-6 col-md-offset-4">
                            <button type="submit" class="btn btn-success">
                                Lihat Pelamar
                            </button>
                        </div>
                    </div>
                </form>
            <?php endif; ?>
            
            <div class="col-sm-4">
            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(Request::fullUrl())); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=no,scrollbars=no,height=400,width=600'); return false;">
                <i class="fa fa-facebook-official"></i>
                Share on Facebook
            </a>
            </div>
            <div class="col-sm-4">
            <a href="https://twitter.com/intent/tweet?url=<?php echo e(urlencode(Request::fullUrl())); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=no,scrollbars=no,height=400,width=600'); return false;">
                <i class="fa fa-twitter"></i> Share on Twitter
            </a>
            </div>

            <div class="col-sm-4">
            <a href='<?php echo e(url("simpan-pdf/$data->id")); ?>' target="_blank">
                <i class="fa fa-save"></i> Simpan Lowker
            </a>
            <!-- <form id="save-form" action='<?php echo e(url("lowker/$data->id")); ?>' method="POST" style="display: none;">
                <input type="submit" name="btn-save">
            </form> -->
            </div>

            <!-- <a id="ref_fb" href="http://www.facebook.com/sharer.php?s=100&amp;p[title]=<?php echo e($data->judul); ?>&amp;p[summary]=<?php echo e($data->deskripsi); ?>&amp;p[url]=<?php echo e(urlencode('127.0.0.1:8000/lowker/1')); ?>&amp; p[images][0]=<?php echo e(public_path('members/default.jpg')); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=no,scrollbars=no,height=400,width=600'); return false;">
            <img src='<?php echo e(asset("members/default.jpg")); ?>' style="width:70px; height:70px" /></a> -->
        </div>
        <div class="col-sm-6" style="background-color: #E1FEA6; max-height: 600px; overflow-y:auto; border-radius: 10px;">
            <h4 align="center"><strong>Daftar Komentar</strong></h4>
            <?php $__currentLoopData = $komentar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-2" style="margin-top: 10px">
                    <?php if(file_exists(public_path("members/$komen->id/$komen->id.jpg"))): ?>
                        <img src='<?php echo e(asset("members/$komen->id/$komen->id.jpg")); ?>' style="width:70px; height:70px" title="<?php echo e($komen->tgl_komen); ?>">
                    <?php else: ?>
                        <img src='<?php echo e(asset("members/default.jpg")); ?>' style="width:70px; height:70px" title="<?php echo e($komen->tgl_komen); ?>">
                    <?php endif; ?>
                </div>
                <div class="col-sm-10" style="margin-top: 10px">
                    <p><a><?php echo e($komen->nama); ?></a></p>
                    <p title="<?php echo e($komen->tgl_komen); ?>"><?php echo e($komen->isi); ?><br><hr>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-12">   
                <form action="<?php echo e(url('/lowker/komentari')); ?>" method="post" align="right" id="newl">
                    <input type="hidden" name="id_lowker" value="<?php echo e($data->id); ?>"><br>
                    <div class="form-group<?php echo e($errors->has('komentar') ? ' has-error' : ''); ?>">
                        <div class="input-group">
                            <input type="text" class="form-control" name="komentar" placeholder="Tulis komentar anda disini. . ." id="komentar"><br>
                            <span class="input-group-btn">
                                <button type="submit" class="btn btn-info btn-sm">Komentari</button> 
                            </span>
                        </div>
                    </div>
                    </div>
                    <p align="center" style="color: red"><strong><?php echo e($errors->first('komentar')); ?></strong></p>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>