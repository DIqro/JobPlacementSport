<?php $__env->startSection('title', 'JPS | Validasi Lowker'); ?>
<?php $__env->startSection("content-admin"); ?>

  <div class="container">
    <h2>Tabel Validasi Lowongan Pekerjaan</h2>                
    <table class="table table-striped">
      <thead>
        <tr>
          <th>ID</th>
          <th>Judul Lowker</th>
          <th>Pemilik</th>
          <th>Deadline Lowker</th>
          <th>Kategori</th>
          <th class="text-center">Aksi</th>
        </tr>
      </thead>

      <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($dt->id_lowker); ?></td>
            <td><?php echo e($dt->judul); ?></td>
            <td><?php echo e($dt->nama); ?></td>
            <td><?php echo e($dt->deadline); ?></td>
            <td><?php echo e($dt->kategori); ?></td>
            <td class="text-center">
              <button id='edit-lowker' data-toggle="modal" data-target="#modalEdit<?php echo e($dt->id_lowker); ?>" class="btn-xs btn-info" type="submit"><i class="fa fa-eye"></i> Details</button>
              <button id='setuju-lowker' data-toggle="modal" data-target="#modalValidasi<?php echo e($dt->id_lowker); ?>" class="btn-xs btn-success"><span class="glyphicon glyphicon-ok"></span> Setuju</button>
              <button id='tolak-lowker' data-toggle="modal" data-target="#modalNonValidasi<?php echo e($dt->id_lowker); ?>" class="btn-xs btn-danger" type="submit"><span class="glyphicon glyphicon-remove"></span> Tidak Setuju</button>
            </td>
          </tr>
          <?php echo $__env->make('layouts.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
<script>
function klikValidasi(){
  $("button").click(function() {
    if(this.id == 'setuju-lowker'){
      $('#message').text('Anda yakin ingin MENYETUJUI lowker ini?');
      $('#aksi').val('setuju');
    }else if(this.id == 'tolak-lowker'){
      $('#message').text('Anda yakin TIDAK MENYETUJUI Lowker ini?');
      $('#aksi').val('tidak-setuju');
    }
  });
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.menu-admin", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>