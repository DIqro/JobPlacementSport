<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" type="text/css" href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <title><?php echo $__env->yieldContent('title'); ?></title> 
    <link rel="shortcut icon" href="favicon.ico"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel='stylesheet' type='text/css' /> 
    <script src="<?php echo e(asset('js/jquery-3.2.1.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script> 
    <link href="<?php echo e(asset('css/style.css')); ?>" rel='stylesheet' type='text/css' />
    <link href="<?php echo e(asset('css/customStyle.css')); ?>" rel='stylesheet' type='text/css' />
    <link href='//fonts.googleapis.com/css?family=Roboto:100,200,300,400,500,600,700,800,900' rel='stylesheet' type='text/css'> 
    <link href="<?php echo e(asset('css/font-awesome.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
</head>
<body>
    <nav class="navbar navbar-default custom-navbar" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('images/Logo JPS Transparan.png')); ?>"></a>
            </div>
            <div class="navbar-collapse collapse" id="bs-example-navbar-collapse-1" style="height: 1px;">
                <ul class="nav navbar-nav">
                    <li class="dropdown dc">
                        <?php if(Session::get('admin') != null): ?> <!-- Admin login -->
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><img src="members/default.jpg"><b class="caret"></b></a>
                        <?php elseif(Auth::guest()): ?> <!-- belum login -->
                        <?php else: ?> <!-- Member login --> 
                            <?php if(file_exists(public_path("members/".Auth::user()->id."/".Auth::user()->id.".jpg"))): ?>
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><img src='<?php echo e(asset("members/".Auth::user()->id."/".Auth::user()->id.".jpg")); ?>'><b class="caret"></b></a>
                            <?php else: ?>
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><img src="members/default.jpg"><b class="caret"></b></a>
                            <?php endif; ?>
                        <?php endif; ?>
                        <ul class="dropdown-menu">
                            <?php if(Session::get('admin') != null): ?> <!-- Admin login -->
                                <li><a href="<?php echo e(url('keluar-admin')); ?>"><i class="fa fa-sign-out"></i> Logout</a></li>
                            <?php else: ?> <!-- Member login -->
                                <li><a href="<?php echo e(url('profil')); ?>"><span class="glyphicon glyphicon-user"></span> Profilku</a></li>
                                <li><a href="<?php echo e(url('lowker/tambah-lowker')); ?>"><i class="fa fa-plus"></i> Tambah Lowker</a></li>
                                <li><a href="<?php echo e(url('notifikasi')); ?>"><i class="fa fa-bell-o"></i> Pemberitahuan</a></li>
                                <li><a href="<?php echo e(url('keluar')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"> <i class="fa fa-sign-out"></i> Logout</a>
                                    <form id="logout-form" action="<?php echo e(url('keluar')); ?>" method="POST" style="display: none;">
                                    </form></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                </ul>
            </div>
            <div class="clearfix"> </div>
        </div>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>
    <div class="footer" style="margin-top: 150px">
      <div class="container">
        <div class="copy">
            <p>Job Placement Sport is a useful web-based application to help users find job vacancies and seek employment in sports. Users looking for job vacancies can directly apply for the desired job vacancy through Job Placement Sport application and for users looking for a workforce can directly select applicants through Job Placement Sport application. </p><br>
            <p>Copyright © 2017 Job Placement Sport</p>
        </div>
      </div>
    </div>
    <!-- <script src="<?php echo e(asset('js/app.js')); ?>"></script>   -->
    <script type="text/javascript">
      $(function(){
        var url = window.location.href;
        $("#menu a").each(function() {
          if(url == (this.href)) { 
              $(this).closest("li").addClass("active");
          }
        });
    });
    </script>
</body>
</html>