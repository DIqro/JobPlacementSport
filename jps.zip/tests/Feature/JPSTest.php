<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithoutMiddleware;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;

class JPSTest extends TestCase
{
    use DatabaseTransactions;

    public function setUp(){
        parent::setUp();
        $this->job = factory('App\Models\M_lowker')->create();
        $this->member = factory('App\Models\M_member')->create();
    }

    /** @test */
    public function member_can_see_jobs_page(){
        $this->actingAs($this->member);
        $this->get('/')->assertSee($this->job->judul);
    }

    /** @test */
    public function member_can_see_single_jobs_page(){
        $this->actingAs($this->member);
        $this->get('/lowker/'. $this->job->id_lowker)->assertSee($this->job->deskripsi);
    }

    /** @test */
    public function guest_cant_create_a_job(){
        $this->get('/lowker/tambah-lowker')->assertRedirect('/');
    }

    /** @test */
    public function member_can_create_a_job(){
        $this->actingAs($this->member);

        $job = factory('App\Models\M_lowker')->make();
        $this->post('/lowker/tambah-lowker', $job->toArray())->assertRedirect('/');
    }

}
